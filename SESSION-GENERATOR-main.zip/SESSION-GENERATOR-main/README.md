# Wasi-Session-Generator
- Kindly star my repo
- Fork and edit as you wish
- Deploy to your favourite hosting server eg Heroku or Render or self hosting

<strong>NB:<strong/> This repo also generates session ID for all bots using whiskeysockets/baileys
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
<br/>QR- WEB - PAIR CODE FOR BOT WITH WHISKEYSOCKETS/BAILEYS
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
<p align="center">
   <a href="https://github.com/Itxxwasi">
    <img src="https://telegra.ph/file/da95ed969f943e4d61ca8.jpg" width="500">
     
</a>
 <p align="center"><img src="https://profile-counter.glitch.me/{Itxxwasi}/count.svg" alt="xcelsama:: Visitor's Count" /></p>



[`ℹ️Contact Owner`](https://wa.me/923192173398)

FORK THE REPOSITORY (Repo) 
    <br>
<a href="https://github.com/Itxxwasi/SESSION-GENERATOR/fork"><img title="WEB" src="https://img.shields.io/badge/FORK Wasi-QR?color=black&style=for-the-badge&logo=stackshare"></a>

Now Deploy
    <br>
<a href='https://dashboard.heroku.com/new?template=https://github.com/Itxxwasi/SESSION-GENERATOR' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/>

[`HERE'S AN EXAMPLE OUTPUT`](https://wasi-session-test-2d5de70f8522.herokuapp.com)
# `Owner`

 <a href="https://github.com/Itxxwasi"><img src="https://github.com/Itxxwasi.png" width="250" height="250" alt="Itxx Me Wasi"/></a>

